int negate (int x) {
	return x * -1;
}

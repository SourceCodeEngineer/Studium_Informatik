int increase (int x) {
	return (x + 1);
}

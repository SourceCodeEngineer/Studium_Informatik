int this_function_should_increment_a_number_by_ten(int x)
{
	return x + 10;
}

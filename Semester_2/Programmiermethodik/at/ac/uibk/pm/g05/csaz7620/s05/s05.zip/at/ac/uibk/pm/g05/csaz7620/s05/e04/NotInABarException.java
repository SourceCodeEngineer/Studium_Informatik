package at.ac.uibk.pm.g05.csaz7620.s05.e04;

public class NotInABarException extends Exception {
    public NotInABarException(String s) {
        super (s);
    }
}

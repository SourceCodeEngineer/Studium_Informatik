package at.ac.uibk.pm.g05.csaz7620.s05.e04;

public class WrongAmountOfDrinksException extends Exception {
    public WrongAmountOfDrinksException(String s) {
        super(s);
    }
}

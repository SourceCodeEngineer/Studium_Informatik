package at.ac.uibk.pm.g05.csaz7620.s04.e02;

public class CourseFullException extends Exception {
    public CourseFullException(String str) {
        super(str);
    }
}

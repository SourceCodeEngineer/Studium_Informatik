package at.ac.uibk.pm.g05.csaz7620.s04.e03;

public enum PasswordStrength {
    TOO_WEAK,
    WEAK,
    MEDIUM,
    STRONG
}

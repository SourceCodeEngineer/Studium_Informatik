package at.ac.uibk.pm.g05.csaz7620.s03.e06;

public class Route {
}

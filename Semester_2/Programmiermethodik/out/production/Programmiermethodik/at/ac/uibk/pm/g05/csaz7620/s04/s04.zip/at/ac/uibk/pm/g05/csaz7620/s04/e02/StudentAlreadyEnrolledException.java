package at.ac.uibk.pm.g05.csaz7620.s04.e02;

public class StudentAlreadyEnrolledException extends Exception {
    public StudentAlreadyEnrolledException(String str) {
        super(str);
    }
}

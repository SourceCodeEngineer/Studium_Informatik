package at.ac.uibk.pm.g05.csaz7620.s06.e02;

public class WrongVoteException extends Exception {
    public WrongVoteException(String str) {
        super(str);
    }
}

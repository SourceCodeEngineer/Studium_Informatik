package at.ac.uibk.pm.g05.csaz7620.s03.e05;

public class Shape {
    private String color;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}

package at.ac.uibk.pm.g05.csaz7620.s02.e02;

public enum CreditRating {
    low,
    medium,
    high
}

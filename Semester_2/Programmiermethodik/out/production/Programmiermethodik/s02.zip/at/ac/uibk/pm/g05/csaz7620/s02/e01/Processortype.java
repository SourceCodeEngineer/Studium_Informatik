package at.ac.uibk.pm.g05.csaz7620.s02.e01;

public enum Processortype {
    AMD,
    Intel
}

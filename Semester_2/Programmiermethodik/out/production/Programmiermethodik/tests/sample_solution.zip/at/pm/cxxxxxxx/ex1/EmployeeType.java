package at.pm.cxxxxxxx.ex1;

public class EmployeeType {

    public static final String ADMINISTRATIVE = "ADMINISTRATIVE";
    public static final String PROFESSOR = "PROFESSOR";
    public static final String STUDENT = "STUDENT";

}
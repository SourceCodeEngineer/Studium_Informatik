package at.pm.cxxxxxxx.ex2;

public class ItemRemovalException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1153633835274663393L;

    public ItemRemovalException(String message) {
        super(message);
    }

}

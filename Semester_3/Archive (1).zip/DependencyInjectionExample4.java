interface INotifier{
	public void sendMessage();
}

class EmailNotifier implements INotifier{

	@Override
	public void sendMessage() {
		// some code to send Email
		System.out.println("Email sent!");
	}
}

class Registration {
	INotifier Notifier;
	
	public Registration(INotifier Notifier) {
		this.Notifier = Notifier;
	}

	public void registerUser() {
		// some code to register user
		System.out.println("User registered!");
		Notifier.sendMessage();
	}
}
public class DependencyInjectionExample4 {

	public static void main(String[] args) {
		Registration registration = new Registration(new EmailNotifier());
		registration.registerUser();
	}

}

import java.util.ArrayList;
import java.util.List;

	abstract class Subject {
		private final List<Observer> observerList = new ArrayList<Observer>();
		
		public void register(Observer newObserver) {
			observerList.add(newObserver);
		}
		public void unregister(Observer newObserver) {
			observerList.remove(newObserver);
		}
		protected void notifyObservers(int state) {
			for (Observer observer : observerList) {
				observer.update(state);
			}
		}
	}

	class ConcreteSubject extends Subject {
		private int state;

		public void setState(int state) {
			this.state = state;
			notifyObservers(state);
		}
		public int getState() {
			return state;
		}
	}

	interface Observer {
		public void update(int state);
	}
	
	class ConcreteObserverA implements Observer {

		public void update(int state) {
			System.out.println("Observer A is updated with " + state);
		}
	}
	class ConcreteObserverB implements Observer {

		public void update(int state) {
			System.out.println("Observer B is updated with " + state);
		}
	}

public class ObserverExample { 

	    public static void main(String[] args) { 
	        ConcreteSubject concreteSubject = new ConcreteSubject(); 
	        concreteSubject.register(new ConcreteObserverA()); 
	        concreteSubject.register(new ConcreteObserverB()); 
	        concreteSubject.setState(2); 
	    } 
	} 	



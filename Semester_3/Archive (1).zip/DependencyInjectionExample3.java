//interface INotifier{
//	public void sendMessage();
//}
//
//class EmailNotifier implements INotifier{
//
//	@Override
//	public void sendMessage() {
//		// some code to send Email
//		System.out.println("Email sent!");
//	}
//}
//
//class Registration {
//	INotifier Email = new EmailNotifier();
//
//	public void registerUser() {
//		// some code to register user
//		System.out.println("User registered!");
//		Email.sendMessage();
//	}
//}
//
//public class DependencyInjectionExample3 {
//
//	public static void main(String[] args) {
//		Registration registration = new Registration();
//		registration.registerUser();
//	}
//
//}

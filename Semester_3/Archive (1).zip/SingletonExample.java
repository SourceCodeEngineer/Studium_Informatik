public class SingletonExample{
	private SingletonExample() {}
	private static class SingletonHolder{
		private final static SingletonExample INSTANCE = new SingletonExample();
	}
	public static SingletonExample getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	
	
}
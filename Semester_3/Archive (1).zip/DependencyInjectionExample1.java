//class EmailNotifier {
//	public void sendEmail() {
//		// some code to send email
//		System.out.println("Email sent!");
//	}
//}
//
//class Registration {
//	EmailNotifier Email = new EmailNotifier();
//
//	public void registerUser() {
//		// some code to register user
//		System.out.println("User registered!");
//		Email.sendEmail();
//	}
//}
//
//public class DependencyInjectionExample1 {
//
//	public static void main(String[] args) {
//		Registration registration = new Registration();
//		registration.registerUser();
//
//	}
//
//}

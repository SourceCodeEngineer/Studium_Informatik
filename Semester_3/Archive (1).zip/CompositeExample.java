import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

interface Shape{
	public abstract void display();
}

class ComposedShape implements Shape{
	List<Shape> container = new ArrayList<Shape>();

	@Override
	public void display() {
		for(Iterator<Shape> itr = container.iterator();itr.hasNext();) {
			itr.next().display();
		}
	}
	public void add(Shape s) {
		container.add(s);
	}
}

class Circle implements Shape{

	@Override
	public void display() {
		System.out.println("Circle");
	}
}

class Rectangle implements Shape{

	@Override
	public void display() {
		System.out.println("Rectangle");	
	}
}

class Triangle implements Shape{
	@Override
	public void display() {
		System.out.println("Triangle");	
	}
}

public class CompositeExample {

	public static void main(String[] args) {
		ComposedShape shape = new ComposedShape();
		Rectangle rect = new Rectangle();
		Triangle tri = new Triangle();
		Circle circ= new Circle();
		shape.add(rect);
		shape.add(circ);
		shape.add(tri);
		shape.display();
	}
}

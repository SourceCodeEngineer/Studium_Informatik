//class SMSNotifier {
//	public void sendSMS() {
//		// some code to send SMS
//		System.out.println("SMS sent!");
//	}
//}
//
//class Registration {
//	SMSNotifier Email = new SMSNotifier();
//
//	public void registerUser() {
//		// some code to register user
//		System.out.println("User registered!");
//		Email.sendSMS();
//	}
//}
//public class DependencyInjectionExample2 {
//
//	public static void main(String[] args) {
//		Registration registration = new Registration();
//		registration.registerUser();
//
//
//	}
//
//}

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorExample {
	public static void main(String[] args) {
		ArrayList<String> mylist = new ArrayList<String>();
		mylist.add("Mary");
		mylist.add("John");
		
		Iterator<String> iter = mylist.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
	}
}




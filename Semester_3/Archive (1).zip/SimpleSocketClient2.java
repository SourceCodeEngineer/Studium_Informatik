import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class SimpleSocketClient2 {
    
    public static void main(String[] args) {
        System.out.println("Trying to connect with server ...");
        Socket server;
        try {
            server = new Socket("localhost",SimpleSocketServer2.SIMPLE_SOCKET_SERVER_PORT);
            System.out.println("Connectd to server " + server.getInetAddress());
            DataInputStream in = new DataInputStream(
                    new BufferedInputStream(server.getInputStream()));
            String serverResponse = in.readUTF();
            System.out.println("Server said " + serverResponse);
            in.close();
            server.close();
        } catch (IOException ex) {
            System.err.println("Error connecting to server");
        }
        System.out.println("terminated.");
    }
    
}





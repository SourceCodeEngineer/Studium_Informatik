import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class SimpleSocketServer2 {

	public static final int SIMPLE_SOCKET_SERVER_PORT = 10123;

	public static void main(String[] args) {
        int port = SIMPLE_SOCKET_SERVER_PORT;
        ServerSocket server = null;
        try {
            server = new ServerSocket(port);
        } catch (IOException ex) {System.err.println("Error registering server socket");
        }
        while(server != null) {
            System.out.println("Waiting for client ...");
            Socket client;
            try {
                client = server.accept();
                System.out.println("Client from " + client.getInetAddress() + " connected");
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(client.getOutputStream()));
                String response = new Date().toString();
                out.writeUTF(response);
                System.out.println("Told client " + response);
                out.flush();
                out.close();
                client.close();
            } catch (IOException ex) {
                System.err.println("Error connecting to client");
            }
        }
        System.out.println("terminated.");
    }
}


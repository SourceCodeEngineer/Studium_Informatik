abstract class GUIFactory {
	public static GUIFactory getFactory() {
		final int sys;
		// Hier muss sys einen Wert bekommen (z.B. aus Konfigurationsdatei)
		// Wir setzen sys gleich 0
		sys = 0;
		if (sys == 0) {
			return new WinFactory();
		} else {
			return new OSXFactory();
		}
	}

	public abstract AbstractButton createButton();
}

class WinFactory extends GUIFactory {
	@Override
	public AbstractButton createButton() {
		return new WinButton();
	}
}

class OSXFactory extends GUIFactory {
	@Override
	public AbstractButton createButton() {
		return new OSXButton();
	}
}
				// Hier muss sys einen Wert bekommen (z.B. aus Konfigurationsdatei)
abstract class AbstractButton {
	public abstract void paint();
}

class WinButton extends AbstractButton {
	@Override
	public void paint() {
		System.out.println("WinButton");
	}
}

class OSXButton extends AbstractButton {
	@Override
	public void paint() {
		System.out.println("OSXButton");
	}
}

public class AbstractFactoryExample {
	// Entspricht der Application Klasse im UML
	public static void main(String[] args) {
		final GUIFactory factory = GUIFactory.getFactory();
		final AbstractButton button = factory.createButton();
		button.paint();
	}

}


